#include "Arduino.h"
#include "Sensor.h"

//Default constructor
Sensor::Sensor() {
  this->ID = -1;
  this->pin = -1;
  this->sensorName = "NULL";      
}

//Parameterised constructor
Sensor::Sensor(int ID, int pin, String sensorName) {
  this->ID = ID;
  this->pin = pin;
  this->sensorName = sensorName;
}

float Sensor::Smooth(int pin) {
  total = total - readings[readIndex];      //Subtract the last reading
  readings[readIndex] = analogRead(pin);    //Read from the sensor
  total = total + readings[readIndex];      //Add the reading to the total
  readIndex = readIndex + 1;                //Advance to the next position in the array

  if (readIndex >= numReadings) {           //If we're at the end of the array
    readIndex = 0;                          //Wrap around to the beginning
  }

  average = total / numReadings;             //Calculate the average:
  delay(1);                                  //Delay in between reads for stability
  return average;                            //Return the average reading
}

int Sensor::getID() {
  return this->ID;
}

int Sensor::getPin() {
  return this->pin;
}

String Sensor::getSensorName() {
  return this->sensorName;
}

float Sensor::getReading() {
  return this->Smooth(this->pin);
}