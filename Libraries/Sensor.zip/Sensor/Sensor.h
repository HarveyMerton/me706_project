/*
  Sensor.h Library for defining sensors used on the MECHENG 706 robot
  Created by Peter Mitchell, 24 March 2021
*/

#ifndef Sensor_h
#define Sensor_h

#include "Arduino.h"


#define numReadings 10

class Sensor {
  private:
    //Sensor properties
    int ID;
    int pin;
    String sensorName;
    //Smoothing function variables
    int readings[numReadings];
    int readIndex = 0;
    int total = 0;
    int average = 0;
    float Smooth(int pin);
  
  public:
    int getID();
    int getPin();
    String getSensorName();
    float getReading();
    //Default constructor
    Sensor();
    //Parameterised constructor
    Sensor(int ID, int pin, String sensorName);
};

#endif