/*
  Sensor.h Library for defining sensors used on the MECHENG 706 robot
  Created by Peter Mitchell, 24 March 2021
*/

#ifndef Sensor_h
#define Sensor_h

#include "Arduino.h"


#define READING_NO 10 //Constant array size for sensor smoothing

class Sensor {
  public:
    //Default constructor
    Sensor(String sensorType, int pin) {
      this->sensorType = sensorType;
      this->pin = pin;
      pinMode(pin, INPUT);
      this->previousTime = 0;
      this->prevReading = 0;
      this->angle = 0;
      this->offset = 0;
    }
    //Ultrasonic constructor
    Sensor(String sensorType, int pin, int pin2) {
      this->sensorType = "ULTRASONIC";
      this->pin = pin;
      this->pin2 = pin2;
      this->offset = 0;
      pinMode(pin, OUTPUT);
      pinMode(pin2, INPUT);
      digitalWrite(pin, LOW);
    }
    //Getters and Setters of private class variables
    float getReading();
    String getSensorType();
    void setAngle(double angleValue);
    void setOffset(double offset);
    double getOffset();
    //Initialisation function used due to moving average smoothing
    void initialise();

  private:
    //Sensor declearation variables for arduino
    String sensorType;
    int pin;
    int pin2;
    double offset;
    int getPin(); //Getter for private variable
    float HC_SR04_range(); //Ultrasonic rage finding algorithm
    //Smoothing function variables
    int readings[READING_NO];
    int idx = 0;
    int total = 0;
    int average = 0;
    float Smooth(float analogReading);
    //Gyroscope variables
    double previousTime;
    float prevReading;
    float angle;
};

#endif