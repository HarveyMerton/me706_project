float IR_short::getReading() {
  float val = 0.0;
    val = 40546.45815 * pow(this->Smooth(analogRead(this->pin)), -1.092180602) + this->offset;
    if (val > 130) return 131;
    else if (val < 40) return 39;
    else return val;
}