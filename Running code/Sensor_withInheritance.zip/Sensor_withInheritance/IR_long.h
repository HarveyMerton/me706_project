/*
  IR_long.h Library for using the long range IR sensor on the MECHENG 706 robot
  Created by Harvey Merton, 24 March 2021
*/

#ifndef IR_long_h
#define IR_long_h

#include "Arduino.h"


class IR : public IR{
  public:
    IR_long(int pin1){ 
	this->pin = pin1;
    }

    float getReading();
};

#endif