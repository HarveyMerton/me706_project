void Gyro::setAngle(double angleValue) {
  this->angle = (angleValue-2.1-this->offset)*1418;
}

float Gyro::getReading() {
  float val = 0.0;

    double currentTime = millis();
    double elapedTime = (double)(currentTime - this->previousTime);

    val = this->Smooth(analogRead(this->pin))-523;

    if (abs(val - prevReading) <= 3) {val = prevReading;}    

    angle += val*elapedTime;
    previousTime = currentTime;
    return this->offset+(2.1+(angle)/1418);

}
