float Sensor::getReading() {
  float val = 0.0;
    val = 152246.3973*pow(this->Smooth(analogRead(this->pin)), -1.184450627)+this->offset;
    if(val > 250) return 251;
    else if(val < 75) return 74;
	else return val;

}