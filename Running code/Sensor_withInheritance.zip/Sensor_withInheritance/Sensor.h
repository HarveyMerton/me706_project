/*
  Sensor.h Library for defining sensors used on the MECHENG 706 robot
  Created by Peter Mitchell, 24 March 2021
*/

#ifndef Sensor_h
#define Sensor_h

#include "Arduino.h"


#define READING_NO 10

class Sensor {
  protected: 
    void setOffset(double offset);
    double getOffset();
    void initialise();

    int pin;
    double offset;
    int getPin();

    //Smoothing function variables
    int readings[READING_NO];
    int idx = 0;
    int total = 0;
    int average = 0;
    float Smooth(float analogReading);
    
  private: 
    Sensor(int pin) {
      this->pin = pin;
      pinMode(pin, INPUT);
      this->offset = 0;
    }
};

#endif