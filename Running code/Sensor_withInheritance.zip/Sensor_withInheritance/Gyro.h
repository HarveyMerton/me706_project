/*
  Gyro.h Library for using the Gyroscope sensor on the MECHENG 706 robot
  Created by Harvey Merton, 24 March 2021
*/

#ifndef Gyro_h
#define Gyro_h

#include "Arduino.h"


class Gyro : public Sensor{
  public:
     Gyro(int pin1){ 
	this->pin = pin1;
    }
    float getReading();
    void setAngle(double angleValue);

  private:

    double previousTime;
    float prevReading;
    float angle;
};

#endif