#include "Arduino.h"
#include "Sensor.h"
#include "math.h"

float Sensor::Smooth(float analogReading) {
  total = total - readings[idx];      //Subtract the last reading
  readings[idx] = analogReading;    //Read from the sensor
  total = total + readings[idx];      //Add the reading to the total
  idx = idx + 1;                			//Advance to the next position in the array

  if (idx >= READING_NO) {           	//If we're at the end of the array
    idx = 0;                          //Wrap around to the beginning
  }

  average = total/READING_NO;         //Calculate the average:
  delay(1);                           //Delay in between reads for stability
  return average;            	        //Return the average reading
}

int Sensor::getPin() {
  return this->pin;
}

void Sensor::setOffset(double offset){
  this->offset = offset;
}

double Sensor::getOffset(){
  return this->offset;
}

void Sensor::initialise() {
  if (this->getSensorType() == "IRTRANSISTOR") {
    for (int i = 0; i < READING_NO; i++){this->getReading();}
  }
  else if (this->getSensorType() == "IRSHORT") {
    for (int i = 0; i < READING_NO; i++){this->getReading();}
  }
  else if (this->getSensorType() == "IRLONG") {
    for (int i = 0; i < READING_NO; i++){this->getReading();}
  }
  else if (this->getSensorType() == "ULTRASONIC") {
    for (int i = 0; i < READING_NO; i++){this->getReading();}
  }
  else if (this->getSensorType() == "GYROSCOPE") {
    for (int i = 0; i < READING_NO; i++){this->getReading();}
    this->setAngle(0);
  }
  else {return;}
}


