/*
  IR.h Library for using the IR sensor on the MECHENG 706 robot
  Created by Harvey Merton, 24 March 2021
*/

#ifndef IR_h
#define IR_h

#include "Arduino.h"


class IR : public Sensor{
  protected: 
    IR(int pin1){ 
	this->pin = pin1;
    }
};

#endif