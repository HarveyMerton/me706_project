/*
  Ultrasonic.h Library for using the US sensor on the MECHENG 706 robot
  Created by Harvey Merton, 24 March 2021
*/

#ifndef Ultrasonic_h
#define Ultrasonic_h

#include "Arduino.h"


class Ultrasonic : public Sensor{
  public:
    Ultrasonic(int pin1, int pin2){ 
	this->pin2 = pin2;
	this->pin = pin1;
    }
    
    float HC_SR04_range();

  private:
    int pin2;
};

#endif