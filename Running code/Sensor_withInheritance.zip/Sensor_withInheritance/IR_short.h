/*
  IR_short.h Library for using the short/medium range IR sensor on the MECHENG 706 robot
  Created by Harvey Merton, 24 March 2021
*/

#ifndef IR_short_h
#define IR_short_h

#include "Arduino.h"


class IR : public IR{
  public:
    IR_short(int pin1){ 
	this->pin = pin1;
    }

    float getReading();
};

#endif