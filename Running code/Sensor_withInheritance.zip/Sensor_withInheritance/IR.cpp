
//Placeholder class for extensibility. 
// Should any functions common to both the short/medium and long range IR sensors be required, they will be implemented here